# discord-quest-completer

Automatically completes Discord quests for your account.

## Setup

```bash
pip install -r requirements.txt
```

## Usage

```bash
python main.py <YOUR_DISCORD_TOKEN>
# or
DISCORD_TOKEN=your_token python main.py
```

## Files

| File | Purpose |
|------|---------|
| `main.py` | Entry point — orchestrates everything |
| `quests.py` | Fetch quests, enroll, quest dict helpers |
| `tasks.py` | One function per task type (video, platform, activity, achievement) |
| `rest.py` | Discord REST client with rate-limit handling |
| `headers.py` | Build desktop/android headers and super-properties |
| `build.py` | Scrapes latest Discord client build number |
| `constants.py` | User agents, API URL, property payloads |

## Supported quest types

- `WATCH_VIDEO` / `WATCH_VIDEO_ON_MOBILE`
- `PLAY_ON_DESKTOP` / `PLAY_ON_XBOX` / `PLAY_ON_PLAYSTATION`
- `PLAY_ACTIVITY`
- `ACHIEVEMENT_IN_ACTIVITY`

> `STREAM_ON_DESKTOP` is not supported — complete those manually in the Discord app.
